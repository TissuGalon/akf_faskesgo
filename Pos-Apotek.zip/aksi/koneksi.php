<?php 
	$servername = "localhost";
	$username = "keluarg8_root";
	$password = "Juanda93*";
	$db = "keluarg8_akf";

	$conn = new mysqli($servername, $username, $password, $db);
	date_default_timezone_set('Asia/Jakarta');
?>